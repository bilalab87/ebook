﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Book
{
    public partial class Form1 : Form
    {
        SqlConnection con = new SqlConnection("Data Source=IT-OPS-6533\\SQLEXPRESS;Initial Catalog=EbookDb;User ID=sa;Password=sa@123");
        SqlCommand cmd;
        SqlDataAdapter adapt;
        //ID variable used in Updating and Deleting Record  
        int ID = 0;
        int ID2 = 0;
        public Form1()
        {
            InitializeComponent();

            this.tabControl1.Location = new System.Drawing.Point(8, 16);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(800, 600);
            this.tabControl1.TabIndex = 0;

            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

            DisplayData();
        }

        private void DisplayData()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from Idioms", con);
            adapt.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textIdioms.Text != "" && txtmeaning.Text != "")
            {
                cmd = new SqlCommand("insert into idioms(Idiom,Meaning) values(@Idiom,@Meaning)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@Idiom", textIdioms.Text);
                cmd.Parameters.AddWithValue("@Meaning", txtmeaning.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }

        private void ClearData()
        {
            txtmeaning.Text = "";
            textIdioms.Text = "";
            ID = 0;
        }

        private void dataGridView1_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
            textIdioms.Text = dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtmeaning.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textIdioms.Text != "" && txtmeaning.Text != "")
            {
                cmd = new SqlCommand("update Idioms set Idiom=@idiom,Meaning=@Meaning where ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.Parameters.AddWithValue("@idiom", textIdioms.Text);
                cmd.Parameters.AddWithValue("@Meaning", txtmeaning.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated Successfully");
                con.Close();
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Update");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (ID != 0)
            {
                cmd = new SqlCommand("delete Idioms where ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", ID);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                DisplayData();
                ClearData();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
        }

      

        private void bindCategory()
        {
            DataRow dr;
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select * from PhraseCategory", con);
            adapt.Fill(dt);

            dr = dt.NewRow();
            dr.ItemArray = new object[] { 0, "--Select Category--" };
            dt.Rows.InsertAt(dr, 0);

            cmbcategory.ValueMember = "id";

            cmbcategory.DisplayMember = "Phrase_category";
            cmbcategory.DataSource = dt;
            con.Close();
        }

      

        private void tabControl1_Selecting(object sender, TabControlCancelEventArgs e)
        {
            int current = (sender as TabControl).SelectedIndex;
            switch (current)
            {
                case 0:
                    ClearData();
                    break;

                case 1:
                    Cleartab2Data();
                    bindCategory();
                    displaphrasedata();

                    break;

               

            }
        }

        private void displaphrasedata()
        {
            con.Open();
            DataTable dt = new DataTable();
            adapt = new SqlDataAdapter("select p.id , pc.Phrase_Category , p.Phrase , pc.Id as id2 from Phrases p , PhraseCategory pc where p.PhraseCategoryID = pc.id", con);
            adapt.Fill(dt);
            dataGridView2.DataSource = dt;
            dataGridView2.Columns["id2"].Visible = false;
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (cmbcategory.SelectedIndex != 0 && txtPhrase.Text !="" )
            {
                cmd = new SqlCommand("insert into Phrases(PhraseCategoryID,Phrase) values(@PhraseCategoryID,@Phrase)", con);
                con.Open();
                cmd.Parameters.AddWithValue("@PhraseCategoryID", cmbcategory.SelectedValue);
                cmd.Parameters.AddWithValue("@Phrase", txtPhrase.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Inserted Successfully");
                displaphrasedata();
                Cleartab2Data();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
       
        }

        private void Cleartab2Data()
        {
            bindCategory();
            txtPhrase.Text = "";
            ID2 = 0;
        }

        private void dataGridView2_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ID2 = Convert.ToInt32(dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString());
            cmbcategory.SelectedValue = dataGridView2.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtPhrase.Text = dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (cmbcategory.SelectedIndex != 0 && txtPhrase.Text != "")
            {
                cmd = new SqlCommand("update Phrases set PhraseCategoryID =@PhraseCategoryID , Phrase=@Phrase", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", ID2);
                cmd.Parameters.AddWithValue("@PhraseCategoryID", cmbcategory.SelectedValue);
                cmd.Parameters.AddWithValue("@Phrase", txtPhrase.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Updated Successfully");
                displaphrasedata();
                Cleartab2Data();
            }
            else
            {
                MessageBox.Show("Please Provide Details!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (ID2 != 0)
            {
                cmd = new SqlCommand("delete Phrases where ID=@id", con);
                con.Open();
                cmd.Parameters.AddWithValue("@id", ID2);
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Record Deleted Successfully!");
                displaphrasedata();
                Cleartab2Data();
            }
            else
            {
                MessageBox.Show("Please Select Record to Delete");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (cmbSearch.SelectedIndex != -1 && txtsearch.Text != "" )
            {

                if (cmbSearch.SelectedItem.ToString() == "Phrases")
                {
                    con.Open();
                    DataTable dt = new DataTable();
                    adapt = new SqlDataAdapter("select p.id , pc.Phrase_Category , p.Phrase , pc.Id as id2 from Phrases p , PhraseCategory pc where p.PhraseCategoryID = pc.id and p.phrase like  '%"+ txtsearch.Text +"%'", con);
                    adapt.Fill(dt);
                    dataGridView3.DataSource = dt;
                    dataGridView3.Columns["id2"].Visible = false;
                    con.Close();
                }

                if (cmbSearch.SelectedItem.ToString() == "Idioms")
                {
                    con.Open();
                    DataTable dt2 = new DataTable();
                    adapt = new SqlDataAdapter("select i.* from Idioms i where  i.idiom  like  '%" + txtsearch.Text + "%'", con);
                    adapt.Fill(dt2);
                    if (dt2 !=null)
                    {
                        dataGridView3.DataSource = dt2;
                    }
                    else
                    {
                        dataGridView3.DataSource = "";

                    }
                    
                   
                    con.Close();
                }

               
            }

            else
            {

                dataGridView3.DataSource = "";
                MessageBox.Show("Please Provide Details!");

            }


        }
    }

      

  
}

